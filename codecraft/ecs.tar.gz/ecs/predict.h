#ifndef __ROUTE_H__
#define __ROUTE_H__

#include "lib_io.h"

void predict_server(char * data[MAX_DATA_NUM],char * info[MAX_INFO_NUM],  int data_line_num,int info_line_num, char * filename);
//void gaussin(double a[][3], double *b,int n);
	

#endif
