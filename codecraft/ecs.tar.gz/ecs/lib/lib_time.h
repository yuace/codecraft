#ifndef __LIB_TIME_H__
#define __LIB_TIME_H__

//打印时间。入参为打印信息头
void print_time(const char * const head);

#endif
